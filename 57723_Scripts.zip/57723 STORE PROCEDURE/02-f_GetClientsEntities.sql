/*    
VERSION		MODIFIEDBY			MODIFIEDDATE	HU		MODIFICATION
1		    Luis Campos			2026-03-02	    55390	Initial Code - Reusable entity resolver (V1/V2)
*/

CREATE OR ALTER FUNCTION [dbo].[f_GetClientsEntities](
    @UserType VARCHAR(32),
    @EntityId VARCHAR(16)
)
RETURNS TABLE
AS
RETURN
(
    SELECT
        CAST(NULL AS VARCHAR(16)) AS Id,
        CAST(NULL AS VARCHAR(16)) AS IdCliente,
        CAST(NULL AS VARCHAR(16)) AS BillToConsigneeId,
        CAST(NULL AS VARCHAR(16)) AS BillToId,
        CAST(NULL AS VARCHAR(16)) AS ConsigneeId,
        CAST(NULL AS VARCHAR(256)) AS BillToName,
        CAST(NULL AS VARCHAR(256)) AS [Name]
    WHERE 
        (@EntityId IS NULL OR @EntityId = '') OR 
        (@UserType NOT IN ('CONSIGNEE', 'BILLTO', 'CLIENTE', 'GRUPOCLIENTE'))

    UNION ALL

    SELECT 
        ER.ChildEntityTypeId AS Id,
        ER.ReferenceId AS IdCliente,
        ER.Id AS BillToConsigneeId,
        ER.EntityTypeId AS BillToId,
        ER.ChildEntityTypeId AS ConsigneeId,
        EN.[Name] AS BillToName,
        ER.Alias AS [Name]
    FROM EntityRelations ER WITH (NOLOCK)
    INNER JOIN EntityTypes ET WITH (NOLOCK) ON ET.Id = ER.EntityTypeId
    INNER JOIN Entities EN WITH (NOLOCK) ON EN.Id = ET.EntityId
    WHERE ET.[Status] IN (1, 3)
    AND ER.[Status] = 1
    AND ER.SubType = 1
    AND ER.ChildEntityTypeId = @EntityId
    AND @UserType = 'CONSIGNEE'

    UNION ALL

    SELECT
        ET.Id,
        NULL AS IdCliente,
        NULL AS BillToConsigneeId,
        NULL AS BillToId,
        ET.Id AS ConsigneeId,
        EN.[Name] AS BillToName,
        EN.[Name] AS [Name]
    FROM EntityTypes ET WITH (NOLOCK)
    INNER JOIN Entities EN WITH (NOLOCK) ON EN.Id = ET.EntityId
    WHERE ET.Id = @EntityId
    AND ET.EntityType = 2
    AND ET.[Status] IN (1, 3)
    AND NOT EXISTS (
        SELECT 1 FROM EntityRelations ER WITH (NOLOCK)
        WHERE ER.ChildEntityTypeId = ET.Id
        AND ER.[Status] = 1
        AND ER.SubType = 1
    )
    AND @UserType = 'CONSIGNEE'

    UNION ALL

    SELECT Id, IdCliente, BillToConsigneeId, BillToId, ConsigneeId, BillToName, [Name]
    FROM dbo.f_SearchEntities(@EntityId, 'IdBillTo')
    WHERE @UserType = 'BILLTO'

    UNION ALL

    SELECT C.id AS Id, C.id AS IdCliente, FSE.BillToConsigneeId, FSE.BillToId, FSE.ConsigneeId, FSE.BillToName, FSE.[Name]
    FROM Clientes C WITH (NOLOCK)
    LEFT JOIN dbo.f_SearchEntities('', 'BillTo') FSE ON C.id = FSE.IdCliente
    WHERE C.id = @EntityId
    AND @UserType = 'CLIENTE'

    UNION ALL

    SELECT GC.IdCliente AS Id, GC.IdCliente, FSE.BillToConsigneeId, FSE.BillToId, FSE.ConsigneeId, FSE.BillToName, FSE.[Name]
    FROM GrupoClientes GC WITH (NOLOCK)
    LEFT JOIN dbo.f_SearchEntities('', 'BillTo') FSE ON GC.IdCliente = FSE.IdCliente
    WHERE GC.IdGrupoCliente = @EntityId
    AND @UserType = 'GRUPOCLIENTE'
)
GO

-- ===============================================================================================================
-- USAGE EXAMPLES
-- ===============================================================================================================
/*
-- Example 1: Single Client lookup
SELECT * FROM dbo.f_GetClientsEntities('CLIENTE', 'CLI012985')

-- Example 2: Group Client lookup
SELECT * FROM dbo.f_GetClientsEntities('GRUPOCLIENTE', 'CLI013680')

-- Example 3: CONSIGNEE lookup
SELECT * FROM dbo.f_GetClientsEntities('CONSIGNEE', 'ETY011990')

-- Example 4: BILLTO lookup
SELECT * FROM dbo.f_GetClientsEntities('BILLTO', 'ETY011')
*/
